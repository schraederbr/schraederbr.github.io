from setuptools import setup

setup(
    name='mySpotipyWheel',
    version='1.0',
    packages=['.mySpotipyWheel'],
)